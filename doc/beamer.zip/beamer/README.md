Beamer - A LaTeX class for producing presentations
==================================================

* See the documentation in doc/beameruserguide.pdf for a user manual.
* See the information in doc/licenses/LICENSE for information on licensing.

This package also uses and includes Translator, a package for translating
words in LaTeX. We welcome new translations.
